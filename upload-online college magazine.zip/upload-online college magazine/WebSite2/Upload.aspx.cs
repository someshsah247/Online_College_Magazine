﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.IO;

public partial class Upload : System.Web.UI.Page
{

    SqlConnection Con = new SqlConnection("Data Source=SHANTI;Initial Catalog=onlinecm;Integrated Security=True;Pooling=False");
    SqlCommand cmd = new SqlCommand();
    private string vid;
    private string img;
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        

        Con.Open();
        Random r = new Random();
        int a = r.Next(12345678);
        String Path = "~\\UploadedImages\\" + a + fileupload1.FileName;
        String query = "insert into vidt values('"+TextBox1.Text+"','"+Path+"')";



        FileInfo f = new FileInfo(Path);
        if (f.Extension == ".jpeg" || f.Extension == ".jpg")
        {
            cmd = new SqlCommand(query, Con);
            cmd.ExecuteNonQuery();
            fileupload1.PostedFile.SaveAs(Server.MapPath(Path));

           // DataList1.DataBind();
            Response.Write("<script>alert('IMAGE UPLOADED')</script>");
        }
        else
        {
            Response.Write("<script>alert('only jpeg')</script>");
        }
        Con.Close();

    }
   

    protected void Button2_Click(object sender, EventArgs e)
    {
       
        Con.Open();
        Random r = new Random();
        int b = r.Next(1234567);
        String Path = "~\\Uploadvideo\\" + r + FileUpload3.FileName;
        String query = "insert into vid values('" +TextBox2.Text + "', '" + Path + "')";



        FileInfo f = new FileInfo(Path);
        if (f.Extension == ".mp4" || f.Extension == ".3gp")
        {
            cmd = new SqlCommand(query, Con);
            cmd.ExecuteNonQuery();
            FileUpload3.PostedFile.SaveAs(Server.MapPath(Path));
           // DataList1.DataBind();
            Response.Write("<script>alert('VIDEO UPLOADED')</script>");
        }
        else
        {
            Response.Write("<script>alert('only mp4 or 3gp')</script>");
        }
        Con.Close();

    }


    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }
}