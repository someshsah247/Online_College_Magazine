﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;


public partial class login : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=SHANTI;Initial Catalog=onlinecm;Integrated Security=True;Pooling=False");
    SqlCommand cmd;
    SqlDataReader dr;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        cmd = new SqlCommand("select * from login where userid='"+lui.Text+"'and password1='"+lpw.Text+"'", con);
        con.Open();
        dr = cmd.ExecuteReader();
        dr.Read();
        if (dr.HasRows)
        {
            if (dr["usertype"].ToString().Equals("U"))
            {
                Response.Redirect("Home.aspx");
            }
            else if (dr["usertype"].ToString().Equals("a"))
            {
                Response.Redirect("");
            }
        }
        else
        {
            Response.Write("<script>alert('Userid Or Password Does Not Match')</script>");
        }
        con.Close();
    }
}