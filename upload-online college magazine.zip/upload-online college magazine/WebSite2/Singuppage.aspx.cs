﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
public partial class Singuppage : System.Web.UI.Page
{
 //   string ConnectionString = ("Data Source=SHANTI;Initial Catalog=onlinecm;Integrated Security=True;Pooling=False");
    SqlConnection con = new SqlConnection("Data Source=SHANTI;Initial Catalog=onlinecm;Integrated Security=True;Pooling=False");
    SqlCommand cmd;



    protected void Page_Load(object sender, EventArgs e)
    {


    }
   
    protected void TextBox5_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        try
        {
            // string query = "insert into online_c_m values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "',,' + TextBox5.Text + ','" + TextBox6.Text + "')";
            con.Open();
            cmd = new SqlCommand("insert into signup values(@userid,@email,@password,@firstname,@lastname,@mobile,@address)", con);
            cmd.Parameters.AddWithValue("@userid", ui.Text);
            cmd.Parameters.AddWithValue("@email", el.Text);
            cmd.Parameters.AddWithValue("@password", pwd.Text);
            cmd.Parameters.AddWithValue("@firstname", fn.Text);
             cmd.Parameters.AddWithValue("@lastname", ln.Text);
                     
             
           
             cmd.Parameters.AddWithValue("@mobile", mn.Text);
             cmd.Parameters.AddWithValue("@address", ad.Text);
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                cmd.CommandText = "insert into login values(@user,@password1,@usertype)";
                cmd.Parameters.AddWithValue("@user", ui.Text);
                cmd.Parameters.AddWithValue("@password1", pwd.Text);
                cmd.Parameters.AddWithValue("@usertype", "U");
                cmd.ExecuteNonQuery();
                Label1.Text = "Sing up completed...";
                con.Close();

            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
    protected void fn_TextChanged(object sender, EventArgs e)
    {

    }
}





