﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.IO;
using System.Web.UI.WebControls.WebParts;


public partial class Gallery : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        
        
        
    }
    protected void DataList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection Con = new SqlConnection("Data Source=SHANTI;Initial Catalog=onlinecm;Integrated Security=True;Pooling=False");
        SqlCommand cmd = new SqlCommand();
        
        Con.Open();
        DataList2.DataBind();

        Con.Close();
    }
}